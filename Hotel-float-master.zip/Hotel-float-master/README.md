# Hotel-float
Hotel website using html and css. Main focus was floats
